class CustomAdapter: RecyclerView.Adapter<CustomAdapter.ViewHolder>()
{
    
    inner class ViewHolder(itemView: View): RecyclerHolder(itemview){
        var itemImage: ImageView
        var itemTitle: TextView
        var itemImage: TextView

    init {
        itemimage = itemView.findViewbyId(R.id.item_image)
        itemimage = itemView.findViewbyId(R.id.item_title)
        itemimage = itemView.findViewbyId(R.id.item_detal)


    }

    }

}